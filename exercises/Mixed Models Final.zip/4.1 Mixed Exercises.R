### Answer Exercise 1

rm(list = ls()) # Clean the workspace
#install.packages("lme4")  # If necesary install the library
library(lme4)              # Call the library to the workspace
library(car)               # Call the library to the workspace
library(lsmeans)           # Call the library to the workspace
library(multcomp)          # Call the library to the workspace

# Read the data
# "PUT HERE THE ADRESS OF THE FILE " #
myfile<-"C:/Users/toledo/Dropbox/UNIPD/Biostatistics Curse  R Spring 2018/curso STAT phD 2018 Mixed Models/data/needle_litter_fall_rbd.txt"
rbd_litter<-read.table(file=myfile,stringsAsFactors = TRUE,header = TRUE,sep = "\t")
options(contrasts = c("contr.SAS","contr.poly"))      # Change contrast options
rbd_litter$block<-as.factor(rbd_litter$block)           # Set block as factor
#rbd_litter$treatment<-as.factor(rbd_litter$treatment) # Set treatment as factor: not necessary because treatment is already alphanumeric (C, I, IF)

# Fit the mixed model
model.1<-lmer(needle_litter_fall ~ treatment + (1 | block) ,data = rbd_litter, REML = TRUE)
summary(model.1)            # Results of the mixed model
AIC(model.1)                # Akaike's Information Criterion (small is better)
BIC(model.1)                # Bayesian Information Criterion (small is better)
Anova(model.1, type=3,test.statistic = "F") # ANOVA table SS type III
lsmeans(model.1,"treatment")      # LSM

#Adding the contrasts to model.1
coef(model.1)                  # See the coefficients of your model
library(multcomp)
K <- matrix(c(0, 1, -1), 1)   # Contrast treatment1 vs treatment2
t <- glht(model.1, linfct = K)             # fit a general linear hypothesis test
summary(t)                             # See the results
K <- matrix(c(0, 1, 0), 1)    # Contrast treatment1 vs treatment3
t <- glht(model.1, linfct = K)             # fit a general linear hypothesis test
summary(t)                             # See the results
K <- matrix(c(0, 0, 1), 1)    # Contrast treatment2 vs treatment3
t <- glht(model.1, linfct = K)             # fit a general linear hypothesis test
summary(t)                             # See the results
K <- matrix(c(0, 1, 1), 1)    # Contrast treatment1+2 vs treatment3
t <- glht(model.1, linfct = K)             # fit a general linear hypothesis test
summary(t)                             # See the results
#remember: df for treatment are 3-1=2, therefore 2 contrasts are allowed!
#in this model the treatment effect is due to the third treatment (IF)


### Answer Exercise 2

#install.packages("lme4")  # If necesary install the library
library(lme4)
# "PUT HERE THE ADRESS OF THE FILE " #
mydata<-read.table(file = "C:/Users/toledo/Dropbox/UNIPD/Biostatistics Curse  R Spring 2018/curso STAT PhD 2018 ExpDesign/data/nested.txt",sep = "\t",header = TRUE,stringsAsFactors = TRUE)
options(contrasts = c("contr.SAS","contr.poly"))      # Change contrast options
mydata$Boar<-as.factor(mydata$Boar) # Set the variable as factor

#### Random Model

model.n<-lmer(ADG ~ Boar + (1|Sow), data = mydata ) # Fit a model with Random effect 
summary(model.n)                 # See the results
anova(model.n)                   # ANOVA


### Answer Exercise 3

rm(list = ls()) # Clean the workspace 
#install.packages("nlme")  # If necesary install the library
library(nlme)              # Call the library to the workspace

# Read the data
# "PUT HERE THE ADRESS OF THE FILE " #
myfile<-"C:/Users/toledo/Dropbox/UNIPD/Biostatistics Curse  R Spring 2018/curso STAT phD 2018 Mixed Models/data/maple.txt"
mydata<-read.table(file=myfile,stringsAsFactors = TRUE,header = TRUE,sep = "\t")
options(contrasts = c("contr.SAS","contr.poly"))      # Change contrast options
mydata$alluminium<-as.factor(mydata$alluminium)       # Set as factor
mydata$seedling<-as.factor(mydata$seedling)           # Set as factor

# Fit the same model with different types of variance and covariance

model.a<-lme(height ~  alluminium + time + alluminium*time, data = mydata, # Model
             random = ~ 1|seedling,                    # Random Effect
             weights = varIdent(form = ~ 1|time),           # Constant variance(s)
             correlation = NULL)                           # No correlation

model.a
anova(model.a)
model.b<-lme(height ~  alluminium + time + alluminium*time, data = mydata, # Model
             random = ~ 1|seedling,                    # Random Effect
             weights = varIdent(form = ~ 1|time),           # Constant variance(s)
             correlation = corAR1())                       # autocorrelation structure of order 1
model.b
anova(model.b)
anova(model.a,model.b)

